﻿namespace Phumla_Kamnandi_Hotel
{


    partial class HotelDatabaseDataSet
    {
        partial class CustomerDataTable
        {
        }

        partial class RoomBookingDataTable
        {
        }
    }
}
